import{u as c,aW as u,aX as d,a5 as i}from"./main-3EPXZM8W.js";import{useCallback as l,useMemo as m}from"react";function p(){const{t}=c(),{addAlert:a,addError:s}=u(),o=l((n,r)=>{if(!(r instanceof d)){s(n,r);return}const e=t(n,{error:r.message});a(e,i.danger,r.description)},[a,s,t]);return m(()=>({addAlert:a,addError:o}),[o,a])}export{p as u};
//# sourceMappingURL=useAccountAlerts-D8IA6smG.js.map
