import{L as n}from"./main-3EPXZM8W.js";const e={dateStyle:"long"},a={timeStyle:"short"},r={...e,...a};function T(t,o=r){return t.toLocaleString(n.languages,o)}export{T as f};
//# sourceMappingURL=formatDate-BHsb5VCU.js.map
