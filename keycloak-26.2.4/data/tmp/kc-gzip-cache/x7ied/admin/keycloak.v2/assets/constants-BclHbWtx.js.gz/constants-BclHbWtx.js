const e="org.keycloak.services.ui.extend.UiPageProvider",o="org.keycloak.services.ui.extend.UiTabProvider";export{e as P,o as T};
//# sourceMappingURL=constants-BclHbWtx.js.map
