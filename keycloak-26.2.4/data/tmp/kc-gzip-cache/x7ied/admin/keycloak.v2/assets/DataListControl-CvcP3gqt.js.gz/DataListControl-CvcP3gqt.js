import{as as e,ar as o}from"./main-Dml5vH_M.js";import*as m from"react";import{s as i}from"./DataListItemRow-B3J1tfyO.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-CvcP3gqt.js.map
