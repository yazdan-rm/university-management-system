import{cd as o}from"./main-Dml5vH_M.js";const n=t=>r=>r&&o(t,r)||"—";export{n as t};
//# sourceMappingURL=translationFormatter-DtFomvax.js.map
