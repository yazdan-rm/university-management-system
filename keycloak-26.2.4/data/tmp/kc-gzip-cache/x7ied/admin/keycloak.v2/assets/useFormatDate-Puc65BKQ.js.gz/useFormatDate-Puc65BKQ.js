import{cX as n}from"./main-Dml5vH_M.js";const s={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{s as F,l as u};
//# sourceMappingURL=useFormatDate-Puc65BKQ.js.map
