import{c as s}from"./main-Dml5vH_M.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-Cmi1OAEj.js.map
